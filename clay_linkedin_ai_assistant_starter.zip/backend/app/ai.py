import os, json
from openai import OpenAI

SYSTEM_PROMPT = '''
You are Clay TechSystems' B2B sales conversation assistant.
Classify the prospect reply into exactly one intent:
Interested, Request for Information, Existing Partner, Follow Up Later,
Not Interested, Do Not Contact, Referral, General Enquiry.
Return JSON with keys: intent, reason, suggested_response, recommended_status.
Use concise, professional Indian enterprise-sales language.
Clay offers ServiceNow, Qlik, Talend, workflow automation and IT/data engineering staff augmentation.
Never pressure a prospect. If they say do not contact, recommend status Do Not Contact
and draft only a brief acknowledgement. If they clearly say not interested, close politely.
Do not invent customer references, credentials, pricing, meeting dates or commitments.
'''

def local_analysis(reply: str) -> dict:
    t = reply.lower()
    if any(x in t for x in ["do not contact", "don't contact", "remove me", "unsubscribe"]):
        return {"intent":"Do Not Contact","reason":"The prospect requested no further contact.","suggested_response":"Thank you for letting us know. We will respect your preference and will not contact you further.","recommended_status":"Do Not Contact"}
    if any(x in t for x in ["not interested", "no requirement", "not looking"]):
        return {"intent":"Not Interested","reason":"The prospect declined further discussion.","suggested_response":"Thank you for your response. We appreciate your time and wish you and your team the very best.","recommended_status":"Closed"}
    if any(x in t for x in ["already have", "existing partner", "current partner"]):
        return {"intent":"Existing Partner","reason":"They already have a partner; the wording should be checked for any explicit capacity or skills gap.","suggested_response":"Thank you for sharing that. We understand. If you ever need additional specialist capacity or support alongside your existing partner, Clay would be happy to explore how we can help.","recommended_status":"Follow-up"}
    if any(x in t for x in ["send", "share", "profile", "details", "information"]):
        return {"intent":"Request for Information","reason":"The prospect has asked for further information.","suggested_response":"Certainly. I would be happy to share Clay TechSystems' company profile and relevant experience. Please let me know which area would be most useful to your team.","recommended_status":"Interested"}
    if any(x in t for x in ["later", "next quarter", "few months", "not now"]):
        return {"intent":"Follow Up Later","reason":"The prospect indicated that a later conversation may be more appropriate.","suggested_response":"Thank you for letting me know. We can reconnect at a more suitable time. Please let us know if there is a particular month you would prefer.","recommended_status":"Follow-up"}
    if any(x in t for x in ["meeting", "meet", "discuss", "interested", "requirement", "project"]):
        return {"intent":"Interested","reason":"The reply suggests openness to a business discussion. A team member should coordinate next steps.","suggested_response":"Thank you for your interest. We would be glad to understand your priorities and explore where Clay could support your team. Please share a convenient time for a discussion.","recommended_status":"Interested"}
    return {"intent":"General Enquiry","reason":"The reply needs human review before choosing a sales action.","suggested_response":"Thank you for getting back to us. We would be happy to understand your priorities and see whether there is a relevant way for Clay to support your team.","recommended_status":"Connected"}

def analyse_reply(reply: str) -> dict:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return local_analysis(reply)
    client = OpenAI(api_key=api_key)
    response = client.responses.create(
        model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
        input=[
            {"role":"system","content":SYSTEM_PROMPT},
            {"role":"user","content":reply}
        ],
        text={"format":{"type":"json_object"}}
    )
    data = json.loads(response.output_text)
    required = ["intent","reason","suggested_response","recommended_status"]
    if not all(k in data for k in required):
        raise ValueError("AI returned an incomplete analysis.")
    return data
