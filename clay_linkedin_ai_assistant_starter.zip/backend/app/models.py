from sqlalchemy import BigInteger, String, Text, DateTime, Enum, ForeignKey, func
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .database import Base

class Prospect(Base):
    __tablename__ = "prospects"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    full_name: Mapped[str] = mapped_column(String(160), nullable=False)
    company: Mapped[str] = mapped_column(String(200), nullable=False)
    designation: Mapped[str | None] = mapped_column(String(160))
    industry: Mapped[str | None] = mapped_column(String(120))
    linkedin_url: Mapped[str | None] = mapped_column(String(500))
    business_email: Mapped[str | None] = mapped_column(String(254))
    source: Mapped[str] = mapped_column(String(80), default="Manual")
    campaign: Mapped[str | None] = mapped_column(String(120))
    owner_profile: Mapped[str] = mapped_column(String(120), default="Anshika")
    status: Mapped[str] = mapped_column(Enum("New","Shortlisted","Connection Pending","Connected","Interested","Follow-up","Closed","Do Not Contact"), default="New")
    next_action: Mapped[str | None] = mapped_column(String(255))
    next_follow_up: Mapped[object | None] = mapped_column(DateTime)
    created_at: Mapped[object] = mapped_column(server_default=func.now())
    updated_at: Mapped[object] = mapped_column(server_default=func.now(), onupdate=func.now())
    conversations: Mapped[list["Conversation"]] = relationship(back_populates="prospect", cascade="all, delete-orphan")

class Conversation(Base):
    __tablename__ = "conversations"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    prospect_id: Mapped[int] = mapped_column(ForeignKey("prospects.id", ondelete="CASCADE"))
    channel: Mapped[str] = mapped_column(Enum("LinkedIn","Email","Other"), default="LinkedIn")
    direction: Mapped[str] = mapped_column(Enum("Inbound","Outbound"))
    message_text: Mapped[str] = mapped_column(Text)
    ai_intent: Mapped[str | None] = mapped_column(String(100))
    ai_reason: Mapped[str | None] = mapped_column(Text)
    suggested_response: Mapped[str | None] = mapped_column(Text)
    approval_status: Mapped[str] = mapped_column(Enum("Pending","Approved","Rejected","Sent Manually"), default="Pending")
    created_at: Mapped[object] = mapped_column(server_default=func.now())
    prospect: Mapped[Prospect] = relationship(back_populates="conversations")
