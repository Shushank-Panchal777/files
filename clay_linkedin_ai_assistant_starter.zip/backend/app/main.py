from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import select, desc
from dotenv import load_dotenv
import os
from .database import get_db, engine, Base
from .models import Prospect, Conversation
from .schemas import ProspectCreate, ProspectUpdate, ProspectOut, ReplyRequest
from .ai import analyse_reply

load_dotenv()
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Clay LinkedIn AI Assistant API", version="0.1.0")
origins = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.get("/api/health")
def health():
    return {"ok": True, "service": "Clay LinkedIn AI Assistant"}

@app.get("/api/prospects", response_model=list[ProspectOut])
def list_prospects(db: Session = Depends(get_db)):
    return list(db.scalars(select(Prospect).order_by(desc(Prospect.created_at))).all())

@app.post("/api/prospects", response_model=ProspectOut)
def create_prospect(payload: ProspectCreate, db: Session = Depends(get_db)):
    obj = Prospect(**payload.model_dump())
    db.add(obj); db.commit(); db.refresh(obj)
    return obj

@app.patch("/api/prospects/{prospect_id}", response_model=ProspectOut)
def update_prospect(prospect_id: int, payload: ProspectUpdate, db: Session = Depends(get_db)):
    obj = db.get(Prospect, prospect_id)
    if not obj: raise HTTPException(404, "Prospect not found")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(obj, key, value)
    db.commit(); db.refresh(obj)
    return obj

@app.delete("/api/prospects/{prospect_id}")
def delete_prospect(prospect_id: int, db: Session = Depends(get_db)):
    obj = db.get(Prospect, prospect_id)
    if not obj: raise HTTPException(404, "Prospect not found")
    db.delete(obj); db.commit()
    return {"deleted": True}

@app.post("/api/ai/analyse-reply")
def analyse(payload: ReplyRequest, db: Session = Depends(get_db)):
    prospect = db.get(Prospect, payload.prospect_id)
    if not prospect: raise HTTPException(404, "Prospect not found")
    try:
        result = analyse_reply(payload.reply_text)
    except Exception as exc:
        raise HTTPException(502, f"AI analysis failed: {str(exc)}")
    conversation = Conversation(
        prospect_id=prospect.id, channel=payload.channel, direction="Inbound",
        message_text=payload.reply_text, ai_intent=result["intent"],
        ai_reason=result["reason"], suggested_response=result["suggested_response"],
        approval_status="Pending"
    )
    prospect.status = result["recommended_status"]
    db.add(conversation); db.commit(); db.refresh(conversation)
    return {"conversation_id": conversation.id, **result}

@app.get("/api/prospects/{prospect_id}/conversations")
def get_conversations(prospect_id: int, db: Session = Depends(get_db)):
    if not db.get(Prospect, prospect_id): raise HTTPException(404, "Prospect not found")
    rows = db.scalars(select(Conversation).where(Conversation.prospect_id == prospect_id).order_by(desc(Conversation.created_at))).all()
    return [{"id":x.id,"channel":x.channel,"direction":x.direction,"message_text":x.message_text,"ai_intent":x.ai_intent,"ai_reason":x.ai_reason,"suggested_response":x.suggested_response,"approval_status":x.approval_status,"created_at":x.created_at} for x in rows]
