CREATE TABLE IF NOT EXISTS prospects (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(160) NOT NULL,
    company VARCHAR(200) NOT NULL,
    designation VARCHAR(160) NULL,
    industry VARCHAR(120) NULL,
    linkedin_url VARCHAR(500) NULL,
    business_email VARCHAR(254) NULL,
    source VARCHAR(80) NOT NULL DEFAULT 'Manual',
    campaign VARCHAR(120) NULL,
    owner_profile VARCHAR(120) NOT NULL DEFAULT 'Anshika',
    status ENUM('New','Shortlisted','Connection Pending','Connected','Interested','Follow-up','Closed','Do Not Contact') NOT NULL DEFAULT 'New',
    next_action VARCHAR(255) NULL,
    next_follow_up DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_prospects_company (company),
    INDEX idx_prospects_status (status),
    INDEX idx_prospects_name (full_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS conversations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    prospect_id BIGINT UNSIGNED NOT NULL,
    channel ENUM('LinkedIn','Email','Other') NOT NULL DEFAULT 'LinkedIn',
    direction ENUM('Inbound','Outbound') NOT NULL,
    message_text TEXT NOT NULL,
    ai_intent VARCHAR(100) NULL,
    ai_reason TEXT NULL,
    suggested_response TEXT NULL,
    approval_status ENUM('Pending','Approved','Rejected','Sent Manually') NOT NULL DEFAULT 'Pending',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_conversations_prospect FOREIGN KEY (prospect_id) REFERENCES prospects(id) ON DELETE CASCADE,
    INDEX idx_conversations_prospect (prospect_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
