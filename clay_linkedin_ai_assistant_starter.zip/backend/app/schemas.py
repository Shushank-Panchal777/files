from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field

class ProspectCreate(BaseModel):
    full_name: str = Field(min_length=1, max_length=160)
    company: str = Field(min_length=1, max_length=200)
    designation: str | None = None
    industry: str | None = None
    linkedin_url: str | None = None
    business_email: str | None = None
    source: str = "Manual"
    campaign: str | None = None
    owner_profile: str = "Anshika"
    status: str = "New"

class ProspectUpdate(BaseModel):
    full_name: str | None = None
    company: str | None = None
    designation: str | None = None
    linkedin_url: str | None = None
    status: str | None = None
    next_action: str | None = None

class ProspectOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    full_name: str
    company: str
    designation: str | None
    industry: str | None
    linkedin_url: str | None
    business_email: str | None
    source: str
    campaign: str | None
    owner_profile: str
    status: str
    next_action: str | None
    created_at: datetime | None = None

class ReplyRequest(BaseModel):
    prospect_id: int
    reply_text: str = Field(min_length=1)
    channel: str = "LinkedIn"

class ReplyAnalysis(BaseModel):
    intent: str
    reason: str
    suggested_response: str
    recommended_status: str
