# Clay LinkedIn AI Assistant (starter)

A human-in-the-loop prospecting and conversation assistant. It does **not** scrape LinkedIn or automate LinkedIn invitations/messages. Users discover/review profiles through permitted sources and manually perform LinkedIn actions.

## Stack
- React + Vite
- FastAPI + SQLAlchemy
- MySQL
- Optional OpenAI API for reply classification and draft generation

## 1. Requirements
- Python 3.10+
- Node.js 18+
- MySQL 8+

## 2. Database
Create a MySQL database and run `database/schema.sql`:

```sql
CREATE DATABASE clay_sales CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Then:
```bash
mysql -u root -p clay_sales < database/schema.sql
```

## 3. Backend
```bash
cd backend
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env   # Windows
# cp .env.example .env   # macOS/Linux
```
Edit `.env` with your MySQL credentials. Start:
```bash
uvicorn app.main:app --reload
```
API docs: http://127.0.0.1:8000/docs

## 4. Frontend
In another terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the URL printed by Vite (normally http://localhost:5173).

## 5. Optional AI
Set `OPENAI_API_KEY` in `backend/.env`. Without a key, the app uses a deterministic local demo classifier. With a key, it uses the OpenAI Responses API.

## First milestone
- Add and view prospects
- Track status and LinkedIn profile URL
- Paste a prospect reply
- Classify intent and generate a suggested response
- Save the reply and draft to the database

Do not put LinkedIn passwords, session cookies, or credentials in this application.
